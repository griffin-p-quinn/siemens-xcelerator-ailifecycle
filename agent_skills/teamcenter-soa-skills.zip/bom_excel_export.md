---
name: bom_excel_export
description: Export Teamcenter BOM context to an Excel roundtrip XLSM via RequirementsManagement services, with optional inline base64 for streamable clients.
---

# BOM Excel Export Skill

Use this skill when the user asks to quickly export a BOM or structure scope into an Excel spreadsheet.

## Goal

Produce a local `.xlsm` file by orchestrating:
- `Internal-AWS2-2014-11-RequirementsManagement/getExportTemplates`
- `Internal-AWS2-2017-06-RequirementsManagement/exportToApplication3`
- FMS download with the returned transient ticket

Use a deterministic tool path for reliability:
- `tc_login`
- `tc_search_smart` (or `tc_search`) to resolve `ItemRevision` UID
- `tc_create_bom_window` to resolve root `BOMLine` UID
- `tc_export_bom_excel` using `BOMLine + ItemRevision`

## Inputs

User-facing required input (preferred):
- `itemId` or an unambiguous part identifier

Backend required inputs for `tc_export_bom_excel`:
- `sourceObjectUid` of type `BOMLine`
- `targetObjectUid` of type `ItemRevision`

UID model:
- Users usually provide one identifier (for example `itemId`).
- Agent derives two backend UIDs from tools:
	- `ItemRevision UID` from search
	- `BOMLine UID` from BOM window

Optional:
- `templateName` (default to `REQ_default_excel_template` when available)
- `outputDir` (default `artifacts/logs/_temp`)
- `outputFileName` (defaults to transient file name)
- `includeContentBase64` (default `false`; set `true` for web/streaming clients)
- `maxInlineBytes` (default `10485760`; cap for inline base64 payload)

## Procedure

1. Ensure authenticated Teamcenter session exists (`tc_login`, optionally `tc_session_info`).
2. Resolve `ItemRevision UID` from the user identifier (`tc_search_smart` + `tc_load_objects` when needed).
3. Open BOM context with `tc_create_bom_window(itemRevUid=...)` and capture root `bomLine.uid`.
4. Call `tc_export_bom_excel` with:
	- `sourceObjectUid=<bomLineUid>`
	- `sourceObjectType=BOMLine`
	- `targetObjectUid=<itemRevisionUid>`
	- `targetObjectType=ItemRevision`
	- optional template/output arguments
5. Return a concise result including:
- selected template
- saved file path
- original file name
- byte size
- sha256
- contentBase64 (when requested)
- key diagnostics
6. Close BOM window (`tc_close_bom_window`) when possible.

## Failure handling

- If requested template does not exist, retry with no `templateName` and inspect `availableTemplates`.
- If transient download fails, return candidate URLs and ticket so user can troubleshoot gateway/FMS access.
- If export returns no templates for `Awb0DesignElement/Awb0ProductContextInfo`, do not guess alternates first; use canonical `BOMLine/ItemRevision` flow.
- If search resolves multiple revisions, stop and ask for user confirmation instead of exporting the wrong revision.
