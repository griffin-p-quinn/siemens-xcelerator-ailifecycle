---
name: change_request_execute
description: Create and submit a Change Request, assign required personnel, and progress/complete an EPM workflow task.
---

# Teamcenter Change Request Execute Skill

Use this skill to automate the Change Request flow observed in Active Workspace interactions.

## Objective
From an in-context object UID:
1) discover valid change types,
2) create + submit Change Request,
3) assign required participants,
4) perform and complete workflow task actions.

## Inputs
- `inContextObjectUid` (required)
- `itemId` (optional; omit when naming rule auto-generates ID)
- `objectName` (required)
- `objectDesc` (optional)
- participant assignments:
  - `participantType` (e.g., `ChangeSpecialist1`, `Analyst`)
  - `assigneeGroupMemberUid`

## Tool sequence
1. Check creatable types
   - `tc_get_creatable_change_types`
   - confirms whether `ChangeRequest` creation is valid for the selected context

2. Create and submit change
   - `tc_create_change`
   - internally maps to create-relate-submit payload with:
     - `boName=ChangeRequest`
     - revision `boName=ChangeRequestRevision`
     - `cm0InContextObjects=[inContextObjectUid]`
     - `submitToWorkflow=true`
    - if item ID naming rule rejects explicit `itemId`, retry with empty/omitted `itemId`
   - parse created revision UID from response `ServiceData.created/modelObjects`
   - do not require `tc_get_workflow_templates` as a precondition for this step; default routing occurs during submit

3. Assign required personnel
   - `tc_add_participants`
   - call once with one or many participant entries

4. Resolve actionable workflow task
   - `tc_find_user_tasks` and/or `tc_load_objects`
   - identify task UID of type `EPMDoTask` linked to the created CR process

5. Progress + complete task
   - `tc_perform_workflow_action` with:
     - `action=SOA_EPM_perform_action`
   - `tc_perform_workflow_action` with:
     - `action=SOA_EPM_complete_action`
     - `supportingValue=SOA_EPM_completed`

6. Verify state
   - `tc_verify_change_outcome` on created revision (require workflow evidence)
   - reload CR/task objects via `tc_load_objects` when extra detail is needed
   - capture completion signals / workflow status fields

## Output contract
Return JSON with:
- `changeRequestRevisionUid`
- `participantsAssigned[]`
- `epmTaskUid`
- `actionsPerformed[]`
- `verification` (`state`, `notes`)
- `rawArtifacts` (optional references)

## Notes from captured interactions
This skill is based on observed successful API calls:
- `Internal-ChangeManagement-2012-10-ChangeManagement/getCreatableChangeTypes`
- `Internal-Core-2012-10-DataManagement/createRelateAndSubmitObjects`
- `Participant-2018-11-Participant/addParticipants`
- `Workflow-2014-06-Workflow/performAction3`
