---
name: part_3d_examine
description: Examine a part's 3D data (QAF/JT), classify payload type, and infer what the geometry preview represents.
---

# Teamcenter Part 3D Examine Skill

Use this skill when you need to inspect and interpret a part's 3D artifacts from Teamcenter BOM context.

## Objective
For each relevant BOM line:
1) find 3D-capable files,
2) inspect payload types (preview image, metadata XML, JT/binary),
3) infer what the part's 3D representation is,
4) return evidence-backed conclusions.

## Inputs
- `itemId` or `itemRevisionUid` (required)
- `maxDepth` (optional, default `3`)
- `maxNodes` (optional, default `300`)
- `maxFiles` (optional, default `120`)
- `includePreviewImage` (optional, default `false`; include preview image URL for `qaf_preview_image`)
- `includePreviewImageBase64` (optional, default `false`; include inline base64 preview bytes when enabled)
- `previewImageMaxBytes` (optional, default `1048576`; max size for inline preview image bytes)

## Tool sequence
1. Baseline 3D coverage
   - `tc_understand_bom_3d`
   - confirms line-level 3D presence and ticket availability.

2. Deep 3D payload examination
   - `tc_understand_bom_3d_deep`
   - classifies each file as:
     - `qaf_preview_image`
     - `qaf_metadata_xml`
     - `jt_or_binary_payload`

3. Part-level interpretation
   - Join by `itemId` + `lineTitle`.
   - Use evidence:
     - preview semantics (`visualSemantics.likelyType`, `tags`)
     - metadata folders (`images/preview`, `part/attrs`, `PMI QAF/Ann3DData`)
     - JT heuristics (`jtDetected`, `version`, `featureHits`) when present.

4. Return structured findings
   - include confidence and reasons.

## Output contract
Return JSON with:
- `summary`
  - `rootItemRevisionUid`
  - `totalLines`
  - `linesWith3D`
  - `rootHasCombined3D`
- `parts[]`
  - `itemId`
  - `lineTitle`
  - `inferred3DMeaning`
  - `confidence`
  - `evidence[]`
  - `files[]` (name, kind, sha256, key diagnostics)
    - for `qaf_preview_image` (when requested):
      - `previewImageUrl`
      - `previewImageBase64` (optional, omitted if size exceeds `previewImageMaxBytes`)

## Interpretation rubric (recommended)
- If preview has `likelyType=qaf_3d_snapshot` and metadata has `PMI QAF/Ann3DData`:
  - infer: "3D mechanical snapshot with PMI-capable package".
- If only metadata exists without preview:
  - infer: "3D package metadata present; preview not available in sampled files".
- If JT payload is detected:
  - infer: "JT geometry payload detected" and report version/features.

## Best use patterns
- **Quick visual confirmation (recommended default)**
  - Call `tc_understand_bom_3d_deep` with `includePreviewImage=true` and `includePreviewImageBase64=false`.
  - Use returned `previewImageUrl` for clickable inspection with low payload size.

- **Inline render in one response**
  - Enable `includePreviewImageBase64=true` with conservative `previewImageMaxBytes`.
  - Keep `maxFiles` lower to avoid oversized responses.

- **Deterministic reporting**
  - Always include `sha256`, `bomLineUid`, `itemId`, and `lineTitle` in evidence.
  - If multiple previews exist, pick one with deterministic ranking (likelyType, size, hash tie-breaker).

- **Fallback behavior**
  - If no preview image exists, return evidence from `qaf_metadata_xml` or `jt_or_binary_payload` rather than failing.

## Notes
- File identity is tied to Teamcenter object lineage (`BOMLine` -> `ItemRevision` -> `Dataset` -> `ImanFile`).
- Conclusions should always include direct evidence references (file name, hash, kind, and diagnostics).
