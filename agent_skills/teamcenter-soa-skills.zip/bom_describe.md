---
name: bom_describe
description: Explore and describe Teamcenter BOMs from an ItemRevision UID, resolve ItemRevision per BOMLine, and return joined line + revision properties.
---

# Teamcenter BOM Describe Skill

Use this skill when you need structured BOM exploration and line-to-item-revision mapping.

## Inputs
- `itemRevUid` (required)
- `expandMode` (`one-level` or `all-level`)
- Optional attribute lists for BOMLine and ItemRevision

## Tool Workflow
1. `tc_create_bom_window`
   - input: `itemRevUid`
   - capture `bomWindow` UID and root `bomLine` UID

2. Expand BOM
   - one-level: `tc_expand_ps_one_level`
   - all-level: `tc_expand_ps_all_levels`

3. Load BOMLine details
   - `tc_load_objects` with `uids=[bomLineUids]`
   - recommended attrs:
     - `bl_indented_title`
     - `bl_quantity`
     - `bl_sequence_no`
     - `bl_item_item_revision`
     - `bl_revision`

4. Resolve ItemRevision UIDs from each line
   - prefer `bl_item_item_revision`
   - fallback `bl_revision`
   - this step is required; do not stop at BOMLine-only output

5. Load ItemRevision details
   - `tc_load_objects` with `uids=[itemRevisionUids]`
   - recommended attrs:
     - `object_name`
     - `object_string`
     - `item_id`
     - `item_revision_id`
     - `release_status_list`

6. Join and return
   - one row per BOMLine with resolved revision and selected properties

7. Cleanup
   - `tc_close_bom_window` with `bomWindowUids=[bomWindowUid]`

## Output Contract
Return JSON:
- `bomWindowUid`
- `rootBomLineUid`
- `lineCount`
- `lines[]` with:
  - `bomLineUid`
  - `lineProps`
  - `itemRevisionUid`
  - `itemRevisionProps`
- `resolvedItemRevisionCount`
- `missingItemRevisionForLines[]`

## Required behavior
- Always traverse from BOMLine references to ItemRevision objects.
- Always include descriptive ItemRevision properties in the final output (`object_name`, `object_string`, `item_id`, `item_revision_id`).
- If a BOMLine does not resolve, include it in `missingItemRevisionForLines[]`.

## Examples
- "Describe BOM for ItemRevision UID `<uid>` and include title, quantity, item_id, item_revision_id."
- "Expand BOM all levels for `<uid>` and return one JSON row per BOMLine with resolved ItemRevision."
