---
name: change_participant_strategy
description: Subskill for role planning and participant assignment in Teamcenter change workflows.
---

# Subskill: Change Participant Strategy

## Purpose
Convert required participant metadata into an executable, deterministic assignment plan.

## Inputs
- Change revision UID
- Candidate GroupMember UID list

## Steps
1. Load change revision with `tc_load_objects`.
2. Extract role model:
   - `awp0RequiredParticipants`
   - `assignable_participant_types`
   - `allowable_participant_types`
3. Compute assignment plan:
   - required roles first,
   - optional roles second,
   - map each role to best-fit candidate.
4. Execute assignments with `tc_add_participants`.
5. Verify `HasParticipant` and role-object creation.

## Output
- `requiredRoles[]`
- `plannedAssignments[]`
- `appliedAssignments[]`
- `failedAssignments[]`
- `missingRequiredRoles[]`
