---
name: change_flow_orchestration
description: End-to-end, theory-informed Teamcenter change flow: select the right change object type, instantiate in context, satisfy required participants, and advance workflow.
---

# Skill: Teamcenter Change Flow Orchestration

## Purpose
Provide a **generic** and reusable method to execute change flows across many Teamcenter change object families (ECR/ECO/deviation/problem report/etc.), not just a single CR template.

This skill combines:
- practical Teamcenter execution steps, and
- established change-management thinking (stakeholder/impact analysis, role clarity, governance checkpoints).

## Conceptual framing (change theory in practice)
Use a lightweight, repeatable loop:
1. **Diagnose change scope** (what is changing, where, why, impact radius)
2. **Select change mechanism** (which change object type and lifecycle fits risk/urgency)
3. **Define accountability** (required participants and decision rights)
4. **Execute and verify** (create, route, assign, advance, validate)

In Teamcenter terms, this means: choosing the right `creatable change type`, then satisfying required participant roles and workflow gates.

## Inputs
- Change context UID(s): target ItemRevision/BOMLine/Program object
- Desired outcome and risk class (cost, schedule, compliance, customer impact)
- Candidate change object type(s) if known
- Candidate assignee GroupMember UID(s)
- Optional selectors for target child resolution from BOM

## Procedure

### 1) Session and policy readiness
1. `tc_login`
2. `tc_session_info`
3. `tc_auth_policy` (ensure mutation path is not blocked)

### 2) Resolve exact in-context target
Use one path:
- direct known ItemRevision UID, or
- BOM path (`tc_create_bom_window` -> `tc_expand_ps_all_levels` -> select child -> `tc_close_bom_window`).

### 3) Select the correct change object type (critical)
1. Call `tc_get_creatable_change_types` for the chosen context.
2. Evaluate options against change intent:
   - Severity / urgency
   - Cross-functional impact and approvals
   - Expected lifecycle and workflow complexity
   - Compliance and traceability needs
3. Pick the **minimal sufficient governance** type:
   - enough control for risk,
   - no unnecessary process burden.

### 4) Create change object and submit workflow
1. Call `tc_create_change` with:
   - `inContextObjectUid`
   - `changeType` and `changeRevisionType` (for CR use `ChangeRequest` / `ChangeRequestRevision`)
   - `objectName` / `objectDesc`
   - optional item ID fields if allowed by naming rules
   - `submitToWorkflow=true` when immediate routing is intended
2. Do not block on `tc_get_workflow_templates` for the default create+submit route.
3. Capture object and revision UIDs + business ID.

### 5) Discover required participant model
1. `tc_load_objects` on change revision with rich properties.
2. Inspect:
   - `awp0RequiredParticipants`
   - `assignable_participant_types`
   - `allowable_participant_types`
   - role-specific assignment fields
3. Build role plan using **internal role keys** (not just display labels).

### 6) Assign participants programmatically
1. For each required role key, call `tc_add_participants`.
2. If multiple candidates are supplied, apply deterministic fallback order.
3. Continue remaining roles on partial failure; report per-role error.

### 7) Advance and verify workflow
1. Check tasks via `tc_find_user_tasks` / `tc_load_objects`.
2. Execute eligible actions using `tc_perform_workflow_action`.
3. Run `tc_verify_change_outcome` on the created revision.
4. Verify required roles are represented and object remains in-process/advanced.

## Success criteria
- Correct change object type selected for context and risk.
- Change object/revision created and routable.
- All required participant roles assigned using valid internal keys.
- Workflow advances without unresolved mandatory-role blockers.

## Failure handling
- Mutation blocked: stop and report policy state.
- No creatable type fit: report options and decision rationale required.
- Role assignment mismatch: reload role metadata and retry with valid key.
- Task action failure: capture task state, allowed actions, and exact service error.

## Notes
- Treat type-selection and participant-design as first-class decisions, not post-create cleanup.
- Prefer deterministic assignment logic and explicit audit outputs for reproducibility.
