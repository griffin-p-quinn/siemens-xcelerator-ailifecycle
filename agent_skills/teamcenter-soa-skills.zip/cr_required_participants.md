---
name: cr_required_participants
description: Create/submit a Change Request from a BOM child, detect required participant roles, and satisfy assignments (including Change Specialist I) programmatically.
---

# Skill: Programmatically Satisfy Required Teamcenter CR Participants (Including Change Specialist I)

## Purpose
Create a Change Request (CR) for a BOM child, submit to workflow, then detect and fulfill required participant assignments programmatically (e.g., `ChangeSpecialist1` / Change Specialist I).

## Preconditions
- MCP endpoint reachable (`/mcp`).
- Teamcenter login valid.
- Mutation operations enabled (runtime restrictions disabled/bypassed or write mode enabled).
- Known target parent revision (`MKSERIES/A`) and GroupMember UID(s) for assignment.

## Inputs
- Parent item revision UID (`MKSERIES/A`: `wrDAAko65BWnuC`)
- Target child selector (e.g., name contains “Exhaust Manifold”)
- CR metadata (`objectName`, `objectDesc`, optional `itemRevisionId`)
- Candidate assignee GroupMember UID(s) (example: `wdKAAMpo5BWnuC`)

## Procedure

### 1) Session and health
1. `tc_login`
2. `tc_session_info`
3. Optional endpoint check via HTTP GET (`405` expected for MCP POST-only route).

### 2) Resolve target child from BOM
1. `tc_create_bom_window` on `wrDAAko65BWnuC`
2. `tc_expand_ps_all_levels`
3. Find target child ItemRevision UID by selector.
   - Example: `xPKAAko65BWnuC` (`3561122/A;1-U - Exhaust Manifold`)
4. `tc_close_bom_window`

### 3) Create and submit CR
1. `tc_create_change` with:
   - `inContextObjectUid=<target_itemrev_uid>`
   - `changeType=ChangeRequest`
   - `changeRevisionType=ChangeRequestRevision`
   - `submitToWorkflow=true`
2. Capture from response:
   - `ChangeRequest` UID
   - `ChangeRequestRevision` UID
   - business ID (e.g., `ECR-000049`)

### 4) Detect required participant roles
1. Load CR revision with rich properties:
   - `tc_load_objects` on `<ChangeRequestRevision UID>`
2. Inspect:
   - `awp0RequiredParticipants` (required role keys)
   - `assignable_participant_types` / `allowable_participant_types` (valid roles)
   - role-specific properties (e.g., `change_specialist1_user_id`, `cm0ChangeSpecialist1`, `analyst_user_id`)

Observed example:
- `awp0RequiredParticipants = ["ChangeSpecialist1"]`
- UI label maps to **Change Specialist I**

### 5) Assign required participants
1. For each required role key, call:
   - `tc_add_participants`
   - `changeRevisionUid=<CR Revision UID>`
   - `participantType=<required role key>` (e.g., `ChangeSpecialist1`)
   - `assigneeGroupMemberUid=<group member uid>`
2. Verify in response:
   - `HasParticipant` includes role assignment
   - role object created (e.g., class `ChangeSpecialist1`)

## Example (validated)
- CR created: `ECR-000049`
- CR Revision UID: `w5MAgoL35BWnuC`
- Required participants detected: `ChangeSpecialist1`
- Added:
  - `Analyst` -> `wdKAAMpo5BWnuC`
  - `ChangeSpecialist1` -> `wdKAAMpo5BWnuC`
- Workflow context confirmed:
  - `fnd0MyWorkflowTasks` includes `Requestor: Assign Specialist`

## Success Criteria
- CR exists and is in process.
- All `awp0RequiredParticipants` roles are represented in `HasParticipant`.
- Role-specific fields are no longer empty where applicable (or role participant object exists).

## Failure Handling
- If mutation blocked: report policy state and stop.
- If no required roles visible: reload full properties and inspect workflow task (`fnd0MyWorkflowTasks`).
- If one role assignment fails: continue remaining roles and report failing `participantType`.

## Notes
- Use internal role key for `participantType` (`ChangeSpecialist1`), not only display label.
- This pattern generalizes to roles beyond Analyst/Specialist.
