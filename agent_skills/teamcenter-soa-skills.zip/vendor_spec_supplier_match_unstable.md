---
name: vendor_spec_supplier_match_unstable
description: Resolve vendor from item via internal VendorManagement API, parse described-by spec PDF, and verify supplier text matches Teamcenter vendor identity.
---

# Skill: Vendor-Spec Supplier Match (UNSTABLE)

Use this skill when you must prove that the supplier named in a spec PDF matches the vendor attached to an item revision.

This flow is intentionally unstable across Teamcenter versions because vendor discovery relies on internal VendorManagement APIs.

## Goal
For a target item (for example `001418`):
1. Resolve attached vendor without pre-known UIDs.
2. Traverse described-by/spec attachment chain.
3. Download and parse PDF evidence.
4. Validate supplier text in PDF equals or clearly matches Teamcenter vendor.

## Required tools
- `tc_get_partner_contracts_unstable` (internal + unstable)
- `tc_expand_grm_relations`
- `tc_load_objects`
- `tc_get_file_read_tickets`
- `tc_download_file`

## Deterministic procedure
1. Resolve vendor attachment:
- Call `tc_get_partner_contracts_unstable` with `itemId` and, when needed, `revisionId`.
- Capture `selectedObjectUid` (ItemRevision UID).
- Extract vendor candidate UID from row properties (prefer `vm1Vendor`; fallback `vm1Partner` only if vendor field is absent).
- Read vendor object via `tc_load_objects` and capture canonical vendor display value (`object_string`).

2. Traverse described-by/spec context:
- Run `tc_expand_grm_relations` from `selectedObjectUid` with relation types:
  - `IMAN_specification`
  - `IMAN_reference`
  - `TC_Attaches`
- Load secondaries via `tc_load_objects`.
- Prioritize `DocumentRevision` / spec-like objects, then traverse one more relation hop to datasets if needed.

3. Resolve PDF binaries:
- From dataset `ref_list`, collect `ImanFile` UIDs.
- Run `tc_get_file_read_tickets`.
- Download using `tc_download_file(includeBase64=true)`.
- Keep only `.pdf` files.

4. Parse supplier text and validate:
- Parse PDF text.
- Extract supplier lines using patterns like `Supplier:`, `Vendor:`, `Contractor/Supplier:`.
- Normalize both strings (casefold, punctuation-stripped, whitespace-collapsed).
- Pass if normalized values are equal or if one clearly contains the other after removing leading vendor code prefixes (for example `002400-`).

## Output contract
Return:
- `itemId`
- `itemRevisionUid`
- `vendorUid`
- `vendorDisplay`
- `documentRevisionUids`
- `pdfCandidates[]`
- `supplierExtracted`
- `match` (`true|false`)
- `matchReason`
- `unstable=true`

## Failure handling
- If vendor rows are empty: fail with `reason=no_vendor_assignment`.
- If no DocumentRevision/PDF path is found: fail with `reason=no_spec_pdf`.
- If PDF parsed but no supplier text found: fail with `reason=no_supplier_text`.
- If supplier text and vendor do not match: fail with `reason=supplier_vendor_mismatch`.
