---
name: search_routing
description: Deterministic Teamcenter search routing for lower-capability models: full-text first, structured fallback second.
---

# Skill: Search Routing Playbook

## Purpose
Give a low-ambiguity search procedure that reduces model decision burden and avoids empty/invalid searches.

## Core rule
1. `tc_search_smart` is the mandatory first-line search entrypoint.
2. When `query` is present, run full-text first and stop if it returns hits.
3. Only use structured saved-query fallback when full-text has no hits (or when no `query` is provided).
4. Always return `strategyUsed`, `fallbackReason`, and `attempts`.

## Minimal decision tree
- If user asks for general search by words/phrase:
  - Use `tc_search_smart(query=...)`.
- If user asks for fielded lookup (for example Item ID, Dataset Type, Owner):
  - Use `tc_search_smart` with `queryName` and `entries` (still full-text first when `query` is provided).
- If no hits:
  - Return no-hit diagnostics from `tc_search_smart`.
  - Do not invent fallback criteria.

## Recommended execution sequence
1. `tc_login` (or reuse active session).
2. `tc_search_smart`.
3. Inspect routing metadata (`strategyUsed`, `fallbackReason`, `attempts`).
4. `tc_load_objects` with returned `objectUids`.
5. Summarize clearly.

## Anti-patterns to avoid
- Calling `tc_search` with empty criteria.
- Calling `tc_execute_saved_query` without clear query name/UID and entries.
- Switching tools mid-flow without reporting strategy metadata.
- Using raw `tc_search`/saved-query tools as default routing instead of `tc_search_smart`.

## Output contract
Return JSON with:
- `strategyUsed`
- `fallbackReason`
- `attempts[]`
- `objectUids[]`
- `loadedObjectsSummary[]`
