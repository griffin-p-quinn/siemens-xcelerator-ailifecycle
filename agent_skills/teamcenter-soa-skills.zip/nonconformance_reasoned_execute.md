---
name: nonconformance_reasoned_execute
description: End-to-end reasoned nonconformance workflow: discover types, resolve exact target revision, parse NCR/CAPA evidence, create+relate+submit, and verify with machine-readable outputs.
---

# Skill: Reasoned Nonconformance Execute

## Purpose
Create a high-confidence Teamcenter nonconformance record that is:
- linked to the exact target ItemRevision,
- supported by parsed document evidence (NCR/CAPA/spec PDFs),
- enriched with structured reason fields,
- submitted to workflow,
- and optionally staffed with required participants.

This skill is designed to avoid the common failure modes:
- wrong revision target,
- missing explicit problem-item relation,
- missing evidence attachments,
- invalid property names (e.g., using `priority` instead of `c2_Priority`).

Absolute type rule:
- If this flow is nonconformance intent, do not create `ChangeRequest` and rename it to look like NCR.
- The created BO type must be nonconformance-capable (for example `C2IssueNonConf`) and verifiably so in readback.

## Inputs
- `targetHint` (required): item ID / revision ID / name phrase (e.g., `002386`)
- `targetRevisionUid` (optional, preferred when known)
- `submissionContext` (optional): user-provided issue text, defect notes, or intake form fields
- `evidenceSelectors` (optional): preferred filenames/keywords such as `NCR`, `CAPA`, `spec`, `drawing`
- `candidateSupplierName` (optional)
- `candidateAssigneeGroupMemberUids[]` (optional)
- `submitToWorkflow` (default `true`)

## Deterministic execution sequence

### 1) Session + mutation readiness
1. `tc_login`
2. `tc_session_info`
3. `tc_auth_policy` (or equivalent runtime-policy check)
4. If mutation is blocked, stop with explicit reason and no partial create attempt.

### 2) Resolve exact target ItemRevision (never guess)
Choose one path:
- If `targetRevisionUid` is provided, `tc_load_objects` and validate identity.
- Else resolve from `targetHint`:
  1. `tc_search_smart` full-text first,
  2. structured fallback query only if needed,
  3. disambiguate by revision ID, object type, and closest text match.

Validation gates:
- must resolve exactly one ItemRevision,
- capture `item_id`, `item_revision_id`, and `uid` in output,
- if multiple plausible revisions remain, fail with ranked candidates (no creation).

### 3) Structural context check (parent/children)
Collect context before creation:
- If BOM context applies: `tc_create_bom_window` -> `tc_expand_ps_all_levels` -> map parent/child neighbors -> `tc_close_bom_window`.
- Prefer `tc_where_used_root_paths` for fast leaf->absolute-parent chain; fall back to `tc_where_used` if needed.

Output should include at least:
- immediate parent candidates,
- immediate child candidates,
- a short risk note about potential blast radius.

### 4) Evidence discovery and PDF parsing
1. Expand revision relations for dataset discovery (spec/reference/supporting docs).
2. Select relevant PDFs using filename and text heuristics (`NCR`, `CAPA`, tolerance/material terms).
3. Retrieve file tickets and download PDFs.
4. Parse text and extract concise evidence snippets:
   - tolerance/spec limits,
   - out-of-tolerance or defect language,
   - material/process context,
   - NCR/CAPA identifiers.

If no parseable PDF evidence is found:
- continue only when `submissionContext` provides enough rationale,
- otherwise fail with `reason=insufficient_evidence`.

### 5) Supplier corroboration
If supplier info exists in submission or evidence:
- run supplier screening/lookup,
- store best candidate + confidence/score metadata,
- if no match, keep original supplier text and flag low confidence (do not block create).

### 6) Discover valid change type for this context
1. Call `tc_get_creatable_change_types` against the in-context target.
2. Prefer a nonconformance-capable type (commonly `C2IssueNonConf`).
3. If unavailable, stop and return available type list + rationale.

### 7) Create nonconformance and submit
Create object in context with concise name/description and `submitToWorkflow` as requested.
Capture:
- created change UID,
- created revision UID,
- business ID.

### 8) Explicitly relate to target revision (mandatory)
Do not rely only on create-in-context semantics.
- Create explicit problem-item relation (commonly `CMHasProblemItem`) between nonconformance revision and target ItemRevision.
- Verify relation existence by expansion/readback.
- If verification fails, mark run as failed even if object creation succeeded.

### 9) Attach evidence datasets (mandatory when available)
For each selected NCR/CAPA/spec dataset:
- create reference relation (commonly `CMReferences`) from nonconformance revision,
- verify each attachment by relation readback.

If an expected NCR/CAPA dataset cannot be attached, include dataset UID and exact service error.

### 10) Populate meaningful NC properties
Set and verify domain fields (adapt to tenant schema):
- priority: use `c2_Priority` (not generic `priority`),
- category/source/contact,
- potential reasons and resolution summary,
- supplier reference fields where applicable.

Property update policy:
- attempt schema-aware mapping,
- record per-property success/failure with exact error text,
- fail only on mandatory fields for current template.

### 11) Optional participant assignment (bonus)
If assignees were provided:
1. Load role metadata from created revision:
   - `awp0RequiredParticipants`,
   - `assignable_participant_types`,
   - `allowable_participant_types`.
2. Prefer required roles first.
3. If `Mendix` participant type exists, assign one provided candidate there.
4. Apply `tc_add_participants` per role and verify role coverage.

Do not fail the whole run for optional participant misses unless required roles remain unfilled.

### 12) Workflow progression check
- Inspect tasks (`tc_find_user_tasks` and/or task load).
- Report current state and actionable transitions.
- Optionally perform action if explicitly requested by caller.

### 13) Mandatory final created-object readback gate
Before declaring success, reload and verify the created revision:
- actual revision type matches nonconformance intent (not `ChangeRequestRevision`),
- non-trivial fields are populated (not only object name/description),
- workflow evidence exists when workflow is expected.

If this gate fails, return `verification.status=failed` or `partial` with explicit failing checks.

## Required output contract
Return JSON with these top-level keys:
- `targetResolution`
- `structureContext`
- `evidence`
- `supplier`
- `creation`
- `relations`
- `attachments`
- `propertyUpdates`
- `participants`
- `workflow`
- `verification`
- `reasoning`

Where:
- `verification.status` is `success` only if target relation + required attachments/property gates pass.
- `reasoning` is machine-readable and must include:
  - `facts[]` (directly observed snippets),
  - `inferences[]` (defect hypothesis tied to facts),
  - `confidence` (0-1),
  - `unknowns[]` (what is still missing).

## Fail-fast conditions
Return `verification.status=failed` when any is true:
1. target revision is ambiguous or unresolved,
2. explicit problem-item relation is missing/unverified,
3. required evidence attachment step fails (when evidence datasets were found),
4. no sufficient rationale from PDFs or submission context,
5. selected change type is not creatable in context.
6. final created-object readback gate fails.

## Practical defaults
- Keep `object_desc` short; place detailed narrative in reason/resolution fields.
- Prefer deterministic selection and explicit verification over optimistic assumptions.
- Always emit artifact references (transcript/summary paths) when available.
