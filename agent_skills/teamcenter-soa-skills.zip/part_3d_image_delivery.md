---
name: part_3d_image_delivery
description: Return clickable 3D preview images from BOM/QAF with safe payload controls for chat and UI use.
---

# Teamcenter Part 3D Image Delivery Skill

Use this skill when you need image-first output (clickable URL and optional inline base64) from Teamcenter 3D artifacts.

## Objective
1) retrieve real preview images for 3D-capable parts,
2) return clickable links for fast viewing,
3) optionally include inline image bytes,
4) keep payload size bounded and deterministic.

## Inputs
- `itemId` or `itemRevisionUid` (required)
- `maxDepth` (optional, default `2` for image workflows)
- `maxNodes` (optional, default `200`)
- `maxFiles` (optional, default `40`)
- `includePreviewImage` (set `true`)
- `includePreviewImageBase64` (optional, default `false`)
- `previewImageMaxBytes` (optional, default `1048576`)

## Tool sequence
1. Discover deep 3D artifacts with image fields
   - `tc_understand_bom_3d_deep`
   - call with:
     - `includePreviewImage=true`
     - `includePreviewImageBase64` as needed
     - `previewImageMaxBytes` for strict limits

2. Filter to image payloads
   - Keep files where `kind == qaf_preview_image`.
   - Prefer entries with `previewImageUrl`.

3. Rank candidate images (recommended)
   - Primary key: `visualSemantics.likelyType == qaf_3d_snapshot`
   - Secondary key: larger area (`jpeg.width * jpeg.height`)
   - Tertiary key: richer semantics tags (`mechanical_geometry_preview`)
   - Tie-breaker: `sha256` ascending

4. Return consumer-ready output
   - Include identity fields (`itemId`, `lineTitle`, `bomLineUid`)
   - Include `previewImageUrl` (clickable)
   - Include `previewImageBase64` only when requested and within cap
   - Include diagnostics (`width`, `height`, `sha256`, `likelyType`, `tags`)

## Best-practice modes
- **Fast mode (chat links)**
  - `includePreviewImage=true`
  - `includePreviewImageBase64=false`
  - Best for fast browsing and low token usage.

- **Embed mode (single-call rendering)**
  - `includePreviewImage=true`
  - `includePreviewImageBase64=true`
  - Set `previewImageMaxBytes` conservatively (`256KB` to `1MB`).

- **Audit mode (repeatable evidence)**
  - Always return `sha256` + `bomLineUid` + `itemId`.
  - Keep deterministic ranking and report selection rationale.

## Output contract
Return JSON with:
- `summary`
  - `rootItemRevisionUid`
  - `partsConsidered`
  - `previewCandidates`
  - `withUrl`
  - `withInlineBase64`
- `previews[]`
  - `itemId`
  - `lineTitle`
  - `bomLineUid`
  - `imageUrl`
  - `imageBase64` (optional)
  - `sha256`
  - `dimensions` (`width`, `height`)
  - `likelyType`
  - `tags[]`
  - `rationale[]`

## Notes
- Do not require inline base64 by default; prefer URL-first responses for scale.
- If no preview exists, report `qaf_metadata_xml` or `jt_or_binary_payload` evidence and fallback rationale.
- Keep response deterministic to support regression checks and reproducibility.
