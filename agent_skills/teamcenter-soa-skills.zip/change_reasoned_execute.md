---
name: change_reasoned_execute
description: Type-adaptive, evidence-driven Teamcenter change execution that selects the right change family, enforces explicit relations, and verifies workflow outcomes.
---

# Skill: Reasoned Change Execute (Type-Adaptive)

## Purpose
Provide one reusable execution pattern that works across multiple Teamcenter change types, including:
- Change Request
- Change Notice
- Deviation Request
- Problem Report
- Non-Conformance Issue
- Quality Issue
- Customer Complaint Issue
- Manufacturing Change Notice
- Action Item / Simple Change

This skill is the general orchestrator. Type-specific skills (for example nonconformance) are specializations.

## Inputs
- `targetHint` or `targetRevisionUid` (required)
- `changeIntent` (required): why this change exists, impact/risk, urgency
- `preferredType` (optional): user-preferred type label/key
- `submissionContext` (optional): intake text and evidence pointers
- `candidateAssignees[]` (optional)
- `submitToWorkflow` (default `true`)

## Type-adaptive flow

### 1) Resolve exact target context
- Validate session and policy readiness.
- Resolve one exact target ItemRevision/BOM context.
- Fail on ambiguity (return ranked candidates, no create).

### 2) Discover creatable type set in context
- Call creatable-type discovery for the exact context.
- Build `availableTypes[]` with raw key + display label.
- If `preferredType` exists and is creatable, select it.
- Else select by governance fit:
  - quality defect -> Non-Conformance / Quality / Problem Report
  - controlled engineering change -> Change Request / Change Notice
  - temporary permission/variance -> Deviation Request
  - customer-originated quality escalation -> Customer Complaint Issue
  - manufacturing process correction -> Manufacturing Change Notice

### 3) Plan relation strategy by selected type
Before create, compute required relation plan:
- `targetRelationType` (for example problem-item or in-context relation)
- `evidenceRelationType` (for attached NCR/CAPA/spec docs)
- optional impacted/reference relations

Always use explicit relation creation + readback verification, not assumptions.

### 4) Create change object and revision
- Create selected type in context with concise name/description.
- Capture object UID, revision UID, business ID, selected type key.

### 5) Enrich with evidence and rationale
- Parse submission context and related docs.
- If datasets are discoverable, parse PDFs and extract facts.
- Build machine-readable reasoning:
  - `facts[]`
  - `inferences[]`
  - `confidence`
  - `unknowns[]`

### 6) Apply schema-aware property updates
- Load available properties for created revision.
- Map intent fields to valid schema keys.
- Apply required fields first, optional fields second.
- Verify by readback and return per-field status.

### 7) Assign required participants and route
- Discover required/allowable participant role keys.
- Assign required roles first using deterministic candidate order.
- Submit/advance workflow as configured.

### 8) Verify completion gates
Success requires:
1. exact target resolved,
2. selected type is valid in context,
3. explicit target relation created + verified,
4. required properties set + verified,
5. required participants satisfied,
6. workflow state is routable/in-process.

### 9) Mandatory final created-object readback gate
Always run a final readback verification on the created revision:
- actual type matches selected type family,
- non-trivial properties are populated (not only title/description),
- workflow evidence exists when workflow is expected.

If this gate fails, final status must be `failed` or `partial` with explicit failing checks.

## Output contract
Return JSON with:
- `targetResolution`
- `typeDiscovery` (`availableTypes`, `selectedType`, `selectionRationale`)
- `relationPlan`
- `creation`
- `evidence`
- `propertyUpdates`
- `participants`
- `workflow`
- `verification`
- `reasoning`

## Specialization hook
If selected type is nonconformance-capable, call/inline the nonconformance specialization workflow (PDF-heavy NCR/CAPA handling, priority/category/source/reason fields, explicit problem-item and references verification).
