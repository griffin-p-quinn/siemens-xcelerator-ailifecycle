---
name: trackside_bracket_incident
description: Trackside incident flow for bracket fit issues: resolve part context, run vendor investigation, parse attachments, submit workflow, and present explicit next-step options.
---

# Skill: Trackside Bracket Incident

## Purpose
Handle a high-pressure motorsport incident where a bracket does not fit and internet is limited.

Primary objective:
- produce one actionable answer that combines Teamcenter object truth and vendor intelligence,
- submit a change/problem workflow,
- and ask the technician for the next concrete action.

Example trigger:
- "The hole is not lining up to the mount on bracket 001418."

## Inputs
- `incidentText` (required): operator text from trackside.
- `partHint` (required): item id or short identifier (for example `001418`).
- `vendorHint` (optional): vendor name or LEI if known (for example `Brembo` or `549300BLWVJN2BAT0A44`).
- `incidentCity` (optional): location city (for rush-order estimation).
- `incidentCountry` (optional): ISO country code.
- `candidateAssignees[]` (optional): GroupMember UIDs for workflow roles.
- `submitToWorkflow` (default `true`).

## Deterministic flow

### 1) Session and readiness
1. `tc_login`
2. `tc_session_info`
3. `tc_auth_policy`
4. If write policy blocks change creation, stop and return exact policy blocker.

### 2) Resolve exact Teamcenter target
1. `tc_search_smart` with `partHint`.
2. `tc_load_objects` on candidates.
3. Select one `ItemRevision` deterministically.
4. If ambiguous, return top candidates and stop before mutation.

### 3) Resolve vendor from Teamcenter first
1. `tc_get_partner_contracts_unstable` using resolved `ItemRevision`.
2. Extract vendor/partner UID (`vm1Vendor` preferred, fallback `vm1Partner`).
3. `tc_load_objects` on vendor UID for canonical display values.

If Teamcenter vendor resolution fails:
- continue with `vendorHint` path only, mark confidence reduced.

### 4) External vendor investigation (name or LEI)
1. `tc_vendor_resolve_identity` using vendor display or `vendorHint`.
2. Choose best identity candidate by confidence.
3. `tc_vendor_get_hierarchy` for parent/child/branch context.
4. `tc_vendor_investigation_report` with incident location for rush-order candidate ranking.

Required outputs:
- primary legal entity (name + LEI),
- direct children,
- parent chain,
- country footprint,
- rush-order candidates with rationale.

### 5) Attachment traversal and evidence parse
1. `tc_expand_grm_relations` from target revision with:
   - `Fnd0IsDescribedByDocument`
   - `IMAN_specification`
   - `IMAN_reference`
   - `TC_Attaches`
2. `tc_load_objects` to find document revisions and dataset-like objects.
3. Collect `ImanFile` UIDs from `ref_list`.
4. `tc_get_file_read_tickets`
5. `tc_download_file` (`includeBase64=true`)
6. Parse text for fit/tolerance/bolt-hole pattern clues.

Evidence rule:
- If no parseable attachment exists, continue using incident text but flag evidence confidence as low.

### 6) Submit change/problem workflow
Canonical sequence:
1. `tc_get_creatable_change_types`
2. `tc_create_change` with `submitToWorkflow=true`
3. `tc_verify_change_outcome`

Then optionally:
4. `tc_add_participants` when required roles are present.

Do not claim submission success unless `tc_verify_change_outcome` confirms expected state.

### 7) Operator response contract (mandatory)
Return short, trackside-ready output with:
- what was looked up,
- what was submitted,
- who the supplier/legal entity is,
- best rush-order path,
- and explicit next-step question.

Template:
1. "I confirmed part `<item_id>/<rev>` and traced supplier `<name>` (`<LEI>`)."
2. "I submitted `<change_id>` and verified workflow state `<state>`."
3. "Closest rush-order candidate is `<entity>` with ETA estimate `<hours>` (planning only)."
4. "Likely causes: `<top 2 causes>`."
5. "Next step: do you want me to (A) check backstock, (B) escalate to supplier now, or (C) compare alternate revisions?"

## Fail-fast conditions
Return `status=failed` when:
1. no deterministic ItemRevision can be selected,
2. mutation policy blocks required create/submit tools,
3. workflow submission cannot be verified,
4. all vendor identity candidates are unresolved and no Teamcenter vendor exists.

## Notes
- Keep vendor assertions split into:
  - Teamcenter contract/vendor truth,
  - external legal-entity corroboration.
- ETA values are planning estimates, not shipping commitments.
- Favor concise trackside messaging over long narratives.