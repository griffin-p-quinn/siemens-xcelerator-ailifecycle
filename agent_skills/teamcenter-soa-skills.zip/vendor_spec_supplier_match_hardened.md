---
name: vendor_spec_supplier_match_hardened
description: Hardened vendor-to-spec supplier validation workflow with explicit described-by relation checks, robust PDF detection, and normalized match verification.
---

# Skill: Vendor-Spec Supplier Match (HARDENED)

Use this skill to prove a Teamcenter vendor assignment matches supplier text in a described-by spec PDF.

## Purpose

Provide a deterministic, tenant-resilient flow for:
1. vendor resolution from ItemRevision,
2. described-by document traversal,
3. PDF reachability and parsing,
4. normalized supplier-vendor comparison.

This is the hardened companion to the unstable vendor-management workflow.

## Required tools

- `tc_get_partner_contracts_unstable`
- `tc_expand_grm_relations`
- `tc_load_objects`
- `tc_get_file_read_tickets`
- `tc_download_file`

## Canonical flow

1. Resolve vendor and selected ItemRevision:
- Call `tc_get_partner_contracts_unstable` with item revision context.
- Prefer vendor UID from `vm1Vendor`; fallback to `vm1Partner`.
- Load vendor object and capture canonical display (`object_string` preferred).

2. Traverse described-by relations from the ItemRevision:
- Use relation set:
  - `Fnd0IsDescribedByDocument`
  - `IMAN_specification`
  - `IMAN_reference`
  - `TC_Attaches`
  - `IMAN_manifestation`
- Check both directions (`primary` and `secondary`) where needed.
- Prioritize `DocumentRevision` candidates.

3. Traverse one additional hop from each `DocumentRevision`:
- Expand same relation set to discover dataset candidates.
- Keep dataset-like objects and collect `ref_list` ImanFile UIDs.

4. Resolve downloadable files and detect PDFs robustly:
- Request tickets via `tc_get_file_read_tickets`.
- Download each candidate via `tc_download_file(includeBase64=true)`.
- Treat as PDF if any condition is true:
  - download `originalFileName` ends with `.pdf`
  - ticket `originalFileName` ends with `.pdf`
  - download `contentType` indicates PDF

Important runtime note:
- FMS downloads may return generic filename values (for example `fmsdownload`) for valid PDFs.
- Do not rely only on download `originalFileName` for PDF detection.

5. Extract supplier text from PDF content:
- Parse with robust line patterns including:
  - `Supplier:`
  - `Preferred supplier:`
  - `Vendor:`
  - `Contractor/Supplier:`
- Trim explanatory tails in the captured value (for example parenthetical notes).

6. Compare supplier against vendor:
- Normalize both values (case-fold, punctuation collapse, whitespace normalize).
- Remove leading numeric vendor-code prefixes when present (for example `002400-`).
- Pass if normalized values are equal or one clearly contains the other.

## Output contract

Return:
- `itemId`
- `itemRevisionUid`
- `vendorUid`
- `vendorDisplay`
- `documentRevisionUids`
- `pdfCandidates[]`
- `supplierExtracted`
- `normalized.vendor`
- `normalized.supplier`
- `match`
- `matchReason`

## Failure taxonomy

- `reason=no_vendor_assignment`
- `reason=no_described_by_document`
- `reason=no_dataset_candidates`
- `reason=no_pdf_reachable`
- `reason=no_supplier_text`
- `reason=supplier_vendor_mismatch`

## Verified reference case

- Item: `001418`
- Document relation: `Fnd0IsDescribedByDocument`
- DocumentRevision example: `RDIAgoOD5BWnuC`
- Attached PDF dataset example: `hrFAgoOD5BWnuC`
- ImanFile example: `hrPAgoOD5BWnuC` (`SRD_001418A_FitSpec.pdf`)
- Supplier extraction example: `Brembo`
- Vendor display example: `002400-BREMBO N.V.`
- Expected match: `true`
