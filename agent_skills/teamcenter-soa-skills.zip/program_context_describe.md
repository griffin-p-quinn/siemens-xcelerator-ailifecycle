---
name: program_context_describe
description: Traverse and summarize Teamcenter Program context including Program, subprojects, events, deliverables, and related tasks.
---

# Teamcenter Program Context Describe Skill

Use this skill when you need to understand Program planning context from real Active Workspace interactions.

## Objective
Given a Program seed (UID, name, or program ID), build a typed hierarchy of Program-related objects:
- `Prg0ProgramPlan`
- `Prg0ProjectPlan`
- `Prg0Event`
- `Prg0Deliverable`
- `Prg0Milestone`
- workflow/task context (`EPMTask`, when available)

## Inputs
- `programSearchText` (required): e.g., `PRG000009` or `Program Orion`
- `maxDepth` (optional, default `2`)
- `maxToReturn` (optional, default `50`)

## Tool sequence
1. Resolve Program candidates
   - `tc_search` with provider `Awp0FullTextSearchProvider`
   - `searchCriteria.searchString=programSearchText`
   - `tc_load_objects` and keep objects with type/className `Prg0ProgramPlan`

2. Load Program details
   - `tc_load_objects` with attributes:
     - `object_name`, `object_desc`, `object_string`, `object_type`
     - `prg0State`, `prg0UnitOfTimeMeasure`
     - `prg0AllowsChildren`, `prg0AllowedChildTypes`, `prg0ParentPlan`
     - `awp0CellProperties`, `fnd0MyWorkflowTasks`

3. Traverse children by context
   - For each Program/Project UID, call `tc_search` with:
     - `searchCriteria.parentUid=<currentUid>`
     - `searchCriteria.searchString=*`
   - `tc_load_objects` for resulting UIDs
   - classify and link children by type

4. Repeat traversal breadth-first
   - Continue until `maxDepth` reached
   - dedupe by UID to avoid loops

5. Return normalized graph
   - keep parent-child links and per-node summaries

## Output contract
Return JSON with:
- `rootPrograms[]`
- `nodesByType` (`Prg0ProgramPlan`, `Prg0ProjectPlan`, `Prg0Event`, `Prg0Deliverable`, `Prg0Milestone`, `EPMTask`)
- `edges[]` (`parentUid`, `childUid`, `childType`)
- `traversalDepthUsed`
- `warnings[]`

## Notes from captured interactions
- Program interactions heavily exercised search/view-model and property loading patterns.
- Core object typing and property hydration are sufficient for reliable Program context summaries without UI-only endpoints.
